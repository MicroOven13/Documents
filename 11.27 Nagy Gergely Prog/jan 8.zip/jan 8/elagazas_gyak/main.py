import metodusok

# metodusok.feladat1()

# metodusok.feladat2()

metodusok.feladat3()